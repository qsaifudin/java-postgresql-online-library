package com.online.library.onlinelibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinelibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
